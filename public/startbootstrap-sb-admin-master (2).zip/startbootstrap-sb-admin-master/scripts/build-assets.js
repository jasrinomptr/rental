'use strict';

const renderAssets = require('./render-assets');

renderAssets();